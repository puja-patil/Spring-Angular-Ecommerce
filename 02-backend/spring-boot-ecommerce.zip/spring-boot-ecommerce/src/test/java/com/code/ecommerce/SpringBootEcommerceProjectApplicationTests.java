package com.code.ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEcommerceProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
